Change log
==========

0.1.0 (2016-11-09)
- Initial commit - added html files for dataset and dimension selector
