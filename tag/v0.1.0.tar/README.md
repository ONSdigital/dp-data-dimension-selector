dp-data-dimension-selector
==========================

Flat HTML prototypes for testing UI of dataset dimension selection and downloading 

### Contributing

See [CONTRIBUTING](CONTRIBUTING.md) for details.

### License

Copyright ©‎ 2016, Office for National Statistics (https://www.ons.gov.uk)

Released under MIT license, see [LICENSE](LICENSE.md) for details.
